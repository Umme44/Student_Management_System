package org.example.final_project.controller;

import org.example.final_project.Certificates;
import org.example.final_project.service.CertificatesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CertificateController {
    @RestController
    @RequestMapping("/api/employee-mgt/certificates")
    public class CertificatesController {

        @Autowired
        private CertificatesService certificateService;

        // Get all certificates
        @GetMapping("/get_all_certificates")
        public List<Certificates> getAllCertificates() {
            return certificateService.getAllCertificates();
        }

        // Create a new certificate
        @PostMapping("/post")
        public Certificates createCertificate(@RequestBody Certificates certificate) {
            return certificateService.createCertificate(certificate);
        }

        // Update an existing certificate
        @PutMapping("/{id}")
        public ResponseEntity<Certificates> updateCertificates(@PathVariable Long id, @RequestBody Certificates certificatesDetails) {
            Certificates updatedCertificate = certificateService.updateCertificate(id, certificatesDetails);
            return ResponseEntity.ok(updatedCertificate);
        }

        // Delete a certificate
        @DeleteMapping("/{id}")
        public ResponseEntity<Map<String, Boolean>> deleteCertificate(@PathVariable Long id) {
            certificateService.deleteCertificate(id);

            Map<String, Boolean> response = new HashMap<>();
            response.put("deleted", Boolean.TRUE);
            return ResponseEntity.ok(response);
        }
    }
}
