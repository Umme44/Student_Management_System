package org.example.final_project.controller;

import org.example.final_project.Certificates;
import org.example.final_project.repo.CertificateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.security.cert.Certificate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employee-mgt/certificates")
public class CertificatesController {

    @Autowired
    private CertificateRepository certificateRepository;

    //Get ALL Certificates
    @GetMapping("/api/employee-mgt/get_all_certificates")
    public List<Certificates> getAllCertificates(){
        return certificateRepository.findAll();

    }

    //Create Certificates
    @PostMapping("/api/employee-mgt/certificates/post")
    public Certificates createCertificate(Certificates certificate){
        return certificateRepository.save(certificate);
    }


    //UPDATE


    @PutMapping("/api/employee-mgt/certificates/{id}")
    public ResponseEntity<Certificates> updateCertificates(@PathVariable Long id, @RequestBody Certificates certificatesDetails) {
        // Fetch the certificate by ID or throw ResourceNotFoundException
        Certificates certificate = certificateRepository.findById(id)
                .orElseThrow();

        // Update fields with new details from certificatesDetails
        certificate.setDescription(certificatesDetails.getDescription());
        certificate.setImageCertificatePath(certificatesDetails.getImageCertificatePath());
        certificate.setCompletion_date(certificatesDetails.getCompletion_date());
        certificate.setEnrolled_date(certificatesDetails.getEnrolled_date());
        certificate.setMaterialsLearned(certificatesDetails.getMaterialsLearned());
        certificate.setExpiration_date(certificatesDetails.getExpiration_date());
        certificate.setIs_expired(certificatesDetails.getIs_expired());

        // Save the updated certificate
        Certificates updatedCertificate = certificateRepository.save(certificate);
        return ResponseEntity.ok(updatedCertificate);
    }



    //DELETE
    @DeleteMapping("/api/employee-mgt/certificates/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteCertificate(@PathVariable Long id) {
        // Find the certificate by ID
        Certificates certificates = certificateRepository.findById(id)
                .orElseThrow();

        // Delete the certificate
        certificateRepository.delete(certificates);

        // Create a response indicating successful deletion
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE); // Use correct key name without parentheses
        return ResponseEntity.ok(response); // Ensure this is ResponseEntity<Map<String, Boolean>>
    }
}
