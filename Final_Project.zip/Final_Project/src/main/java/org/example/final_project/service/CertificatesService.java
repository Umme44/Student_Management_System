package org.example.final_project.service;


import org.example.final_project.Certificates;
import org.example.final_project.controller.ResourceNotFoundException;
import org.example.final_project.repo.CertificateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CertificatesService {

    @Autowired
    private CertificateRepository certificateRepository;

    // Get all certificates
    public List<Certificates> getAllCertificates() {
        return certificateRepository.findAll();
    }

    // Create a new certificate
    public Certificates createCertificate(Certificates certificate) {
        return certificateRepository.save(certificate);
    }

    // Update an existing certificate
    public Certificates updateCertificate(Long id, Certificates certificateDetails) {
        Certificates certificate = certificateRepository.findById(id)
                .orElseThrow();

        certificate.setDescription(certificateDetails.getDescription());
        certificate.setImageCertificatePath(certificateDetails.getImageCertificatePath());
        certificate.setCompletion_date(certificateDetails.getCompletion_date());
        certificate.setEnrolled_date(certificateDetails.getEnrolled_date());
        certificate.setMaterialsLearned(certificateDetails.getMaterialsLearned());
        certificate.setExpiration_date(certificateDetails.getExpiration_date());
        certificate.setIs_expired(certificateDetails.getIs_expired());

        return certificateRepository.save(certificate);
    }

    // Delete a certificate
    public void deleteCertificate(Long id) {
        Certificates certificate = certificateRepository.findById(id)
                .orElseThrow();

        certificateRepository.delete(certificate);
    }
}
