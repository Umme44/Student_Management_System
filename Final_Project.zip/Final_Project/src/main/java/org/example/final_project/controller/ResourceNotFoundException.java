package org.example.final_project.controller;

public class ResourceNotFoundException {
    public ResourceNotFoundException(String s) {
    }
}
